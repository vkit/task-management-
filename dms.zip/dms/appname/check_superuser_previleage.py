from appname.models import UserProfile
from django.contrib import messages


def check_superuser_func(request, user):
	userprofile = UserProfile.objects.get(user=user)
	if not userprofile.user_type == 4:
		messages.error(request, 'Oops!You Dont have Permission to Chnage this')
	

