from django.conf.urls import url



from . import views

from django.conf import settings

from django.contrib.auth.views import LogoutView



urlpatterns = [

	url(r'^login/$', views.login_user, name='login'),

	url(r'^load_categories/$', views.load_subcategory, name='load_categories'),

	url(r'^dashboard/$', views.dashboard, name='dashboard'),

	# url(r'^ajax/validate_username/$', views.validate_username, name='validate_username'),

	# url(r'^not_started_task_count/$', views.not_started_task_count, name='not_started_task_count'),

	url(r'^test_assigny/$', views.assignytest, name='test_assigny'),


	url(r'^create_task/$', views.create_task, name='create_task'),

	url(r'^create_task_manager/$', views.create_task_manager, name='create_task_manager'),

	url(r'^books/(?P<id>\d+)/update$', views.book_update, name='book_update'),

	url(r'^book_list/$', views.book_list, name='book_list'),

	url(r'^book_create/$', views.book_create, name='book_create'),

	

	# url(r'^resassign_user/(?P<id>\d+)/$', views.task_reassign_user, name='resassign_user'),



	url(r'^task_list_assigny/$', views.task_list_assigny, name='task_list_assigny'),
	
	# url(r'^task_list/$', views.task_list, name='task_list'),

	url(r'^user_list/$', views.add_user, name='user_list'),

	# url(r'^user_list/$', views.user_list, name='user_list'),

	url(r'^delete_user/(?P<pk>\d+)/$',views.delete_user, name='delete_user'),

	# url(r'^delete_user/$', views.delete_user, name='delete_user'),

	url(r'^client_list/$', views.add_client, name='client_list'),

	# url(r'^client_list/$', views.client_list, name='client_list'),

	url(r'^update_client/(?P<pk>\d+)/$',views.update_client, name='update_client'),

	url(r'^category_list/$', views.add_category, name='category_list'),

	# url(r'^category_list/$', views.category_list, name='category_list'),

	url(r'^sub_category_list/$', views.add_sub_category, name='sub_category_list'),

	url(r'^update_sub_category/(?P<pk>\d+)/$',views.update_sub_category, name='update_sub_category'),

	url(r'^update_category/(?P<pk>\d+)/$',views.update_category, name='update_category'),

	url(r'^closed_task_lis/$', views.closed_task_list, name='closed_task_lis'),

	url(r'^open_task_list/$', views.open_task_list, name='open_task_list'),
	
	url(r'^task_list_by_assigny/$', views.task_list_by_assigny, name='task_list_by_assigny'),

	url(r'^task_list_by_client/$', views.task_list_by_client, name='task_list_by_client'),

	url(r'^task_list_by_category/$', views.task_list_by_category, name='task_list_by_category'),


	url(r'^close_task/(?P<pk>\d+)/$',views.close_task, name='close_task'),

	url(r'^delete_task/(?P<pk>\d+)/$',views.delete_task, name='delete_task'),

	# url(r'^update_task/(?P<pk>\d+)/$',views.update_task, name='update_task'),

	url(r'^(?P<pk>\d+)/detail/$', views.TaskDetailView.as_view(),
        name='detail'),
    url(r'^(?P<pk>\d+)/comment/$', views.TaskCommentView.as_view(),
        name='comment'),

    url(r'^(?P<pk>\d+)/update/$', views.TaskupdateView.as_view(),
        name='update'),
    url(r'^(?P<pk>\d+)/late_reason/$', views.LateReasonView.as_view(),
        name='late_reason'),
    
	# url(r'^add_history/(?P<pk>\d+)/$',views.add_task_history, name='add_history'),

	url(r'^logout/$', LogoutView.as_view(), {'next_page': settings.LOGOUT_REDIRECT_URL}, name='logout'),

	url(r'^not_startd_task/$', views.not_startd_task, name='not_startd_task'),

	url(r'^overdue_task_list/$', views.overdue_task_list, name='overdue_task_list'),

	url(r'^waiting_approval_list/$', views.waiting_approval_list, name='waiting_approval_list'),

	url(r'^change_password/$', views.change_password, name='change_password'),


	url(r'^approve_late_task/(?P<pk>\d+)/$',views.approve_late_task, name='approve_late_task'),

	# url(r'^closed_task_count/$', views.closed_task_count, name='closed_task_count'),
	

	
]