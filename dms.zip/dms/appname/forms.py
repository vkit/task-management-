from django import forms
from .models import Task, Assigny, Client, Category, SubCategory, TaskComment, UserProfile
from django.contrib.auth.models import User
from .approval_status import APPROVAL
from django.conf import settings

class TaskForm(forms.ModelForm):
    client = forms.ModelChoiceField(required=True, queryset=Client.objects.filter(ative_flag='ACTIVE'))
    task_detail = forms.CharField(required=True, widget=forms.Textarea)
    notice_reference = forms.CharField(label='Notice Reference', 
                    widget=forms.TextInput(attrs={'placeholder': 'Enter Notice Reference'}))
    due_date = forms.DateField(required=True, input_formats=settings.DATE_INPUT_FORMATS, widget=forms.DateInput(attrs={'placeholder': 'DD-MM-YYYY', 'required': 'True'}))
    assigny = forms.ModelChoiceField(required=True, queryset=Assigny.objects.all())
    reviwed_by = forms.ModelChoiceField(required=True, queryset=UserProfile.objects.exclude(user_type=1))
    category = forms.ModelChoiceField(required=True, queryset=Category.objects.filter(category_status='ACTIVE'))
    # client = forms
    # file_attach = forms.FileField(widget=forms.ClearableFileInput(attrs={'multiple': True}), required=True)
    # name = forms.CharField(max_length=100, required=True)
    # address = forms.CharField(max_length=100, required=True)

    class Meta:
        model = Task
        fields = (
            'client', 
            'category', 
            'sub_category', 
            'task_detail',
            'notice_reference',
            'due_date',
            'assigny',
            'reviwed_by',
        )
    def __init__(self, *args, **kwargs):
        super(TaskForm, self).__init__(*args, **kwargs)
        self.fields['sub_category'].queryset = SubCategory.objects.none()

        if 'category' in self.data:
            try:
                category_id = int(self.data.get('category'))
                self.fields['sub_category'].queryset = SubCategory.objects.filter(category_id=category_id).order_by('sub_category_name')
            except (ValueError, TypeError):
                pass
        elif self.instance.pk:
            self.fields['sub_category'].queryset = self.instance.category.category.order_by('sub_category_name')


class UpdateTaskForm(forms.ModelForm):
    expected_closure_date = forms.DateField(required=True, input_formats=settings.DATE_INPUT_FORMATS, widget=forms.DateInput(attrs={'placeholder': 'DD-MM-YYYY', 'required': 'True'}))

    class Meta:
        model = Task
        fields = (
            'expected_closure_date',
        )


class ClientForm(forms.ModelForm):
    # file_attach = forms.FileField(widget=forms.ClearableFileInput(attrs={'multiple': True}), required=True)
    # name = forms.CharField(max_length=100, required=True)
    # address = forms.CharField(max_length=100, required=True)
    client_name = forms.CharField(required=True, label='Client Name', 
                    widget=forms.TextInput(attrs={'placeholder': 'Enter Client Name'}))
    city = forms.CharField(required=True, label='City', 
                    widget=forms.TextInput(attrs={'placeholder': 'Enter City Name'}))
    state = forms.CharField(required=True, label='State', 
                    widget=forms.TextInput(attrs={'placeholder': 'Enter State Name'}))
    mobile = forms.CharField(label='Mobile', widget=forms.TextInput(attrs={'type': 'number'}))

    phone_office = forms.CharField(label='Office Phone', widget=forms.TextInput(attrs={'type': 'number'}))

    email1 = forms.EmailField(required=True)

    address = forms.CharField(required=True, widget=forms.Textarea)

    class Meta:
        model = Client
        fields = (
            'ative_flag', 
            'client_name', 
            'address', 
            'city', 
            'state',
            'phone_office',
            'mobile',
            'email1',
            'email2',
            'client_type',
            'pan_no_entity',
            'tan_no',
            'gst_no',
        )


class CategoryForm(forms.ModelForm):
    # file_attach = forms.FileField(widget=forms.ClearableFileInput(attrs={'multiple': True}), required=True)
    # name = forms.CharField(max_length=100, required=True)
    # address = forms.CharField(max_length=100, required=True)
    # client_name = forms.CharField(max_length=100, required=True)
    category_name = forms.CharField(required=True, label='Category Name', 
                    widget=forms.TextInput(attrs={'placeholder': 'Enter Category Name'}))
    
    class Meta:
        model = Category
        fields = (
            'category_status', 
            'category_name', 
        )

class SubcategoryForm(forms.ModelForm):
    # file_attach = forms.FileField(widget=forms.ClearableFileInput(attrs={'multiple': True}), required=True)
    # name = forms.CharField(max_length=100, required=True)
    # address = forms.CharField(max_length=100, required=True)
    # client_name = forms.CharField(max_length=100, required=True)
    category = forms.ModelChoiceField(required=True, queryset=Category.objects.all())
    sub_category_name = forms.CharField(required=True, label='Sub Category Name', 
                    widget=forms.TextInput(attrs={'placeholder': 'Enter Sub Category Name'}))

    class Meta:
        model = SubCategory
        fields = (
            'sub_category_status', 
            'category',
            'sub_category_name',
        )


class TaskCommentForm(forms.ModelForm):
    # file_attach = forms.FileField(widget=forms.ClearableFileInput(attrs={'multiple': True}), required=True)
    # name = forms.CharField(max_length=100, required=True)
    # address = forms.CharField(max_length=100, required=True)
    # client_name = forms.CharField(max_length=100, required=True)
    task_comment = forms.CharField(required=True, widget=forms.Textarea)

    class Meta:
        model = TaskComment
        fields = (
            'task_comment_stage', 
            'task_comment',
        )

class LateApprovalForm(forms.ModelForm):
    late_approval_reason = forms.CharField(
     widget=forms.Textarea(attrs={'placeholder': 'Please Write Reason for Late Approval'}))
    # late_action_approval = forms.ChoiceField(required=True, choices=APPROVAL, widget=forms.RadioSelect())
    # file_attach = forms.FileField(widget=forms.ClearableFileInput(attrs={'multiple': True}), required=True)
    # name = forms.CharField(max_length=100, required=True)
    # address = forms.CharField(max_length=100, required=True)
    # client_name = forms.CharField(max_length=100, required=True)

    class Meta:
        model = Task
        fields = (

            'late_approval_reason',

        )

class SanityCheckOneForm(forms.ModelForm):
    # late_action_approval = forms.ChoiceField(choices=APPROVAL, widget=forms.RadioSelect(), required=True)
    # file_attach = forms.FileField(widget=forms.ClearableFileInput(attrs={'multiple': True}), required=True)
    # name = forms.CharField(max_length=100, required=True)
    # address = forms.CharField(max_length=100, required=True)
    # client_name = forms.CharField(max_length=100, required=True)

    class Meta:
        model = Task
        fields = (

            'due_date',

        )


class ReassignUserForm(forms.ModelForm):
    class Meta:
        model = Task
        assigny = forms.ModelChoiceField(required=True, queryset=Assigny.objects.all())
        expected_closure_date = forms.DateField(required=True, input_formats=settings.DATE_INPUT_FORMATS, widget=forms.DateInput(attrs={'placeholder': 'DD-MM-YYYY', 'required': 'True'}))
        fields = ('assigny','expected_closure_date')