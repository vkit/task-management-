# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.contrib.auth.models import User

from django.template.loader import render_to_string
from django.http import JsonResponse

from django.db.models import Q

from django.contrib.auth import authenticate, login

from django.contrib.auth.mixins import LoginRequiredMixin

from django.views.generic import ListView, View, DetailView

from django.contrib.auth.decorators import login_required

from django.shortcuts import get_list_or_404, get_object_or_404

from django.contrib import messages

from django.shortcuts import render

from django.shortcuts import HttpResponseRedirect

from .models import Task, Client, UserProfile, Assigny, Category, SubCategory

from .forms import TaskForm, ClientForm, CategoryForm, SubcategoryForm, TaskCommentForm, LateApprovalForm, UpdateTaskForm, ReassignUserForm

from datetime import date, timedelta

import datetime



def load_subcategory(request):
    category_id = request.GET.get('category')
    sub_categories = SubCategory.objects.filter(category=category_id).order_by('sub_category_name')
    return render(request, 'sub_categories_dropdown.html', {'sub_categories': sub_categories})


# def validate_username(request):
#     username = request.GET.get('username', None)
#     data = {
#         'is_taken': User.objects.filter(username__iexact=username).exists()
#     }
#     return JsonResponse(data)


def not_started_task_count(request):
    user = request.user
    lis = []
    context = {}
    task_lists = Task.objects.filter(is_active=True)
    today_date = date.today()
    for task_list in task_lists:
        if task_list.assigny_closure_date>today_date and task_list.assignee_status=='NOT STARTED':
            lis.append(task_list)
            # context['task_list'] = len(lis)
    print("count", len(lis))
    return render(request, 'dashboard.html', {'not_started_count':len(lis)})



def dashboard(request):
    not_started_lis = []
    task_lists = Task.objects.filter(is_active=True)
    today_date = date.today()
    overdue_task = Task.objects.filter(expected_closure_date__lte=today_date, assignee_status='NOT STARTED').count()

    closed_count = Task.objects.filter(task_status='CLOSED').count()

    open_task = Task.objects.filter(expected_closure_date__gte=today_date).filter(~Q(task_status = 'CLOSED')).count()

    waiting_list_count = Task.objects.filter(late_action_approval='Yes',late_action_approval_status='PENDING').count()


    
    return render(request, 'dashboard.html', {'overdue_task':overdue_task, 'closed_count': closed_count, 'open_task': open_task, 'waiting_list_count': waiting_list_count})


def assignytest(request):
    return render(request, 'base_manager.html')

def login_user(request):
    try:
        if request.method == 'POST':
            username = request.POST['username']
            password = request.POST['password']


            user = authenticate(username=username, password=password)
            
            if user is not None:
                if user.is_active:
                    login(request, user)
                    userprofile = UserProfile.objects.get(user=user)
                    if userprofile.user_type ==4:
                        return HttpResponseRedirect('/appname/dashboard/')
                    elif userprofile.user_type ==1:
                        return HttpResponseRedirect('/appname/task_list_assigny/')
                    elif userprofile.user_type == 2:
                        return HttpResponseRedirect('/appname/create_task_manager/')
            else:
                messages.error(request, 'Oops!Username and Password were Incorect! Please check Your Username and Password')
                return HttpResponseRedirect('/appname/login/')

        return render(request, 'registration/login.html')
    except User.DoesNotExist:
        messages.error(
            request, 'Oops!Username and Password were Incorect! Please check Your Username and Password')
        return HttpResponseRedirect('/appname/login/')




# This is for superuser
@login_required
def create_task(request):
    try:
        user = request.user

        form = TaskForm(request.POST)

        userprofile = UserProfile.objects.get(user=user)

        if form.is_valid():

            userprofile = UserProfile.objects.get(user=user)
            if userprofile.user_type ==1 or userprofile.user_type==3:
                messages.error(request, 'Oops!You Dont Have Permission to Add the Task')
                return HttpResponseRedirect('/appname/create_task/')

            instance = form.instance
            instance.task_created_by = user
            instance.expected_closure_date = instance.due_date-timedelta(days=2)

            instance.save()

            form.save()
            messages.success(request, 'Well done!Your Task is Submitted Succesfully.')
            return HttpResponseRedirect('/appname/create_task/')
        else:
            form = TaskForm()
        return render(request, 'task_list.html', {'books': Task.objects.filter(is_active=True),'today_date':date.today(), 'form': form})
    except Exception as e:
        print(e)


# This is for manager
@login_required
def create_task_manager(request):
    try:
        user = request.user

        form = TaskForm(request.POST)

        userprofile = UserProfile.objects.get(user=user)

        if form.is_valid():

            userprofile = UserProfile.objects.get(user=user)
            if userprofile.user_type ==1 or userprofile.user_type==3:
                messages.error(request, 'Oops!You Dont Have Permission to Add the Task')
                return HttpResponseRedirect('/appname/create_task_manager/')

            instance = form.instance
            instance.task_created_by = user
            instance.expected_closure_date = instance.due_date-timedelta(days=2)

            instance.save()

            form.save()
            messages.success(request, 'Well done!Your Task is Submitted Succesfully.')
            return HttpResponseRedirect('/appname/create_task_manager/')
        else:
            form = TaskForm()
        return render(request, 'task_list_manager.html', {'books': Task.objects.filter(is_active=True).filter(task_status='OPEN'),'today_date':date.today(),'user':user, 'form': form})
    except Exception as e:
        print(e)




def book_list(request):
    books = Task.objects.all()
    context = {
    'books': books
    }
    return render(request, 'book_list.html',context)

@login_required
def save_all(request,form,template_name):
    user = request.user
    data = dict()
    if request.method == 'POST':
        if form.is_valid():
            form.save()
            data['form_is_valid'] = True
            books = Task.objects.filter(is_active=True).filter(task_status='OPEN')
            data['book_list'] = render_to_string('book_list_2.html',{'books':books})
        else:
            data['form_is_valid'] = False
    context = {
    'form':form,
    'user': user,
    }
    data['html_form'] = render_to_string(template_name,context,request=request)
    return JsonResponse(data)

def book_create(request):
    if request.method == 'POST':
        form = TaskForm(request.POST)
    else:
        form = TaskForm()
    return save_all(request,form,'book_create.html')

def book_update(request,id):
    book = get_object_or_404(Task,id=id)
    if request.method == 'POST':
        form = ReassignUserForm(request.POST,instance=book)
    else:
        form = ReassignUserForm(instance=book)
    return save_all(request,form,'book_update.html')

def book_delete(request,id):
    data = dict()
    book = get_object_or_404(Book,id=id)
    if request.method == "POST":
        book.delete()
        data['form_is_valid'] = True
        books = Book.objects.all()
        data['book_list'] = render_to_string('book_list_2.html',{'books':books})
    else:
        context = {'book':book}
        data['html_form'] = render_to_string('book_delete.html',context,request=request)

    return JsonResponse(data)


# This is Assigny Task View

#Here only Assigny can view his own task

@login_required
def task_list_assigny(request):
    user = request.user
    userprofile = UserProfile.objects.get(user=user)

    return render(request, 'assigny_task_list.html', {'var_raw': Task.objects.filter(is_active=True).filter(assigny__user__username=user), 'today_date':date.today()})




# @login_required
# def update_task(request, pk):
#     user = request.user
#     instance = get_object_or_404(Task, pk=pk)

#     form = TaskForm(request.POST or None, instance=instance)

#     if form.is_valid():
#         instance = form.instance
#         instance.task_updated_by = user
#         instance.save()
#         form.save()
#         userprofile = UserProfile.objects.get(user=user)

#         if userprofile.user_type == 4:

#             messages.error(request, 'Well done!Your Data is Updated Succesfully.')
#             return HttpResponseRedirect('/appname/create_task/')
#         elif userprofile.user_type == 1:
#             return HttpResponseRedirect('/appname/task_list_assigny/')
#     return render(request, 'task_update.html', {'form': form, 'instance': instance})





# Close the Task

# Still Permission is pending
@login_required
def close_task(request, pk):
    try:
        user = request.user
        if request.method =='POST':
            task_id = get_object_or_404(Task, pk=pk)
            userprofile = UserProfile.objects.get(user=user)
            # if not userprofile.user_type ==4:
            #     messages.error(request, 'Oops!You Dont Have Permission to Close The Task')
            #     return HttpResponseRedirect('/appname/create_task/')
            task_id.task_status='CLOSED'
            task_id.save()
            messages.success(request, "well Done! Your Task is Closed Succcesfully")
            return HttpResponseRedirect('/appname/create_task/')
        return render(request, 'task_list.html')
    except Exception as e:
        print(e)

# Still it is not assigned

@login_required
def delete_task(request, pk):
    try:
        user = request.user
        if request.method =='POST':
            task_id = get_object_or_404(Task, pk=pk)
            userprofile = UserProfile.objects.get(user=user)
            # if not userprofile.user_type ==4:
            #     messages.error(request, 'Oops!You Dont Have Permission to Delete The Task')
            #     return HttpResponseRedirect('/appname/create_task/')
            task_id.is_active = False
            task_id.save()
            messages.success(request, "Well Done! Your Task is Deleted Succesfully")
            return HttpResponseRedirect('/appname/create_task/')
        return render(request, 'task_list.html')
    except Exception as e:
        print(e)


# @login_required
# def task_list(request):
#     user = request.user
#     userprofile = UserProfile.objects.get(user=user)
#     if userprofile.user_type == 3:
#         messages.error(request, 'Oops! You Dont have Permission to Acess this')
#         return HttpResponseRedirect('/appname/task_list/')
#     return render(request, 'task_list.html', {'var_raw': Task.objects.all()})

# View task by Closed Task
@login_required
def closed_task_list(request):
    user = request.user
    return render(request, 'closed_task_lis.html', {'closed_task': Task.objects.filter(task_status='CLOSED')})


@login_required
def open_task_list(request):
    user = request.user
    today_date = date.today()
    return render(request, 'open_task_list.html', {'books': Task.objects.filter(expected_closure_date__gte=today_date).filter(~Q(task_status = 'CLOSED'))})

#View Task by Assigny
@login_required
def task_list_by_assigny(request):
    user = request.user
    context = {}
    if request.method =='POST':
        username = request.POST['username']
        # context = {'task_username': Task.objects.filter(task_created_by__username=username)}
        context['task_username'] = Task.objects.filter(assigny__user__username=username)

    return render(request, 'task_list_assigny.html', context)

@login_required
def task_list_by_client(request):
    try:
        user = request.user
        context = {}
        if request.method =='POST':
            client_name = request.POST['client_name']

            context['client_lis'] = Task.objects.filter(client__client_name=client_name)
        return render(request, 'task_lis_fil_client.html', context )
    except Exception as e:
        print(e)

@login_required
def task_list_by_category(request):
    try:
        user = request.user
        context = {}
        if request.method =='POST':
            category_name = request.POST['category_name']

            context['category_lis'] = Task.objects.filter(category__category_name=category_name)
            print("context", context)
        return render(request, 'task_lis_fil_category.html', context )
    except Exception as e:
        print(e)


@login_required
def add_user(request):
    try:
        user = request.user
        if request.method =='POST':
            username = request.POST['username']
            password = request.POST['password']
            user_type = request.POST['user_type']
            userprofile = UserProfile.objects.get(user=user)
            if not userprofile.user_type == 4:
                messages.error(request, 'Oops!You Dont have Permission to Add the User')
                return HttpResponseRedirect('/appname/user_list/')
            if User.objects.filter(username=username).exists():
                messages.error(
                request, 'Oops!That Username Already Exists.')
                return HttpResponseRedirect('/appname/user_list/')
            else:
                user = User.objects.create_user(username=username, password=password)
            # user = authenticate(username=username, password=password)
            
            # login(request, user)
            user_name = User.objects.get(username=user)
            if user_type == 'Assigny':
                UserProfile.objects.create(user=user_name, user_type=1)
                Assigny.objects.create(user=user_name)
                messages.success(request, 'well Done!Your User is Succesfully Created')
                return HttpResponseRedirect("/appname/user_list/")

            elif user_type =='Manager':
                UserProfile.objects.create(user=user_name, user_type=2)
                messages.success(request, 'well Done!Your User is Succesfully Created')
                return HttpResponseRedirect("/appname/user_list/")

            elif user_type =='Admin':
                UserProfile.objects.create(user=user_name, user_type=3)
                messages.success(request, 'well Done!Your User is Succesfully Created')
                return HttpResponseRedirect("/appname/user_list/")
            else:
                UserProfile.objects.create(user=user_name, user_type=4)
                messages.success(request, 'well Done!Your User is Succesfully Created')
                return HttpResponseRedirect("/appname/user_list/")
        return render(request, 'registration/add_user.html', {'user_var': User.objects.all()})
    except Exception as e:
        print(e)




# def delete_user(request):
#     try:
#         user = request.user

#         if request.method=='POST':
#             username = request.POST['username']
#             userprofile = UserProfile.objects.get(user=user)
#             if not userprofile.user_type == 4:
#                 messages.error(request, 'Oops!You Dont have Permission to Add the User')
#                 return HttpResponseRedirect('/appname/create_task/')

#             User.objects.filter(username=username).delete()
#             messages.success(request, 'Well Done! User is Successfully Removed')
#             return HttpResponseRedirect('/appname/create_task/')
#         return render(request, 'delete_user.html')
#     except Exception as e:
#         print(e)

def delete_user(request, pk):
    try:
        user = request.user
        if request.method == 'POST':
            instance = get_object_or_404(User, pk=pk)
            userprofile = UserProfile.objects.get(user=user)
            if not userprofile.user_type==4:
                messages.error(request, 'Oops!You Dont have Permission to Add the User')
                return HttpResponseRedirect('/appname/user_list/')
            instance.delete()
            messages.success(
                request, 'User Deleted Succesfully')
            return HttpResponseRedirect('/appname/user_list/')
        return render(request, 'user_lis.html')
    except Exception as e:
        print(e)


@login_required
def add_client(request):
    try:
        user = request.user

        if request.method =='POST':

            ative_flag = request.POST['ative_flag']

            client_name = request.POST['client_name']

            address = request.POST['address']

            city = request.POST['city']

            state = request.POST['state']

            phone_office = request.POST['phone_office']

            mobile = request.POST['mobile']

            email1 = request.POST['email1']

            email2 = request.POST['email2']

            client_type = request.POST['client_type']

            pan_no_entity = request.POST['pan_no_entity']

            tan_no = request.POST['tan_no']

            gst_no = request.POST['gst_no']

            userprofile = UserProfile.objects.get(user=user)

            if not userprofile.user_type==4:
                messages.error(request, 'Oops!You Dont have Permission to Add Client')
                return HttpResponseRedirect('/appname/add_client/')

            Client.objects.create(
                ative_flag=ative_flag,
                client_name=client_name,
                address=address,
                city=city,
                state=state,
                phone_office=phone_office,
                mobile=mobile,
                email1=email1,
                email2=email2,
                client_type=client_type,
                pan_no_entity=pan_no_entity,
                tan_no=tan_no,
                gst_no=gst_no,
                created_by=user,
            )
            messages.success(request, 'Well Done! Client Data Added Succesfully')
            return HttpResponseRedirect('/appname/client_list/')
        return render(request, 'add_client.html', {'client_lis': Client.objects.all()})
    except Exception as e:
        print(e)

@login_required
def update_client(request, pk):
    user = request.user
    instance = get_object_or_404(Client, pk=pk)
    form = ClientForm(request.POST or None, instance=instance)
    if form.is_valid():
        userprofile = UserProfile.objects.get(user=user)
        if not userprofile.user_type ==4:
            messages.error(request, 'Oops!You Dont have Permission to Update the fields')
            return HttpResponseRedirect(
            '/appname/client_list/')
        instance = form.instance
        instance.updated_by = user
        form.save()
        messages.success(
        request, 'Well done!Your Data is Updated Succesfully.')
        return HttpResponseRedirect('/appname/client_list/')
    return render(request, 'client_update.html', {'form': form, 'instance': instance})

# @login_required
# def client_list(request):
#     user = request.user
#     return render(request, 'client_lis.html', {'client_lis': Client.objects.all()})


@login_required
def add_category(request):
    try:
        user = request.user

        if request.method =='POST':
            category_status=request.POST['category_status']

            category_name = request.POST['category_name']

            userprofile = UserProfile.objects.get(user=user)

            if not userprofile.user_type==4:
                messages.error(request, 'Oops!You Dont have Permission to Add Category')
                return HttpResponseRedirect('/appname/category_list/')
            Category.objects.create(
                category_status=request.POST['category_status'],

                category_name=request.POST['category_name'],

                created_by=user
            )

            messages.success(request, 'Well Done! Category Data Added Succesfully')

            return HttpResponseRedirect('/appname/category_list/')
        return render(request, 'add_category.html', {'category_lis': Category.objects.all()})
    except Exception as e:
        print(e)

# @login_required
# def category_list(request):
#     user = request.user
#     userprofile = UserProfile.objects.get(user=user)
#     if not userprofile.user_type==4:
#         messages.error(request, 'You Dont have Permission')
#         return HttpResponseRedirect('/appname/category_list/')
#     return render(request, 'category_lis.html', {'category_lis': Category.objects.all()})


@login_required
def update_category(request, pk):
    user = request.user 
    instance = get_object_or_404(Category, pk=pk)
    form = CategoryForm(request.POST or None, instance=instance)
    if form.is_valid():
        userprofile = UserProfile.objects.get(user=user)
        if not userprofile.user_type ==4:
            messages.error(request, 'You Dont have Permission to Update This')
            return HttpResponseRedirect('/appname/category_list/')
        form.save()
        messages.success(
        request, 'Well done!Your Data is Updated Succesfully.')
        return HttpResponseRedirect('/appname/category_list/')
    return render(request, 'category_update.html', {'form': form, 'instance': instance})


@login_required
def add_sub_category(request):
    try:
        user = request.user

        print "user", user

        form = SubcategoryForm(request.POST)

        userprofile = UserProfile.objects.get(user=user)

        if form.is_valid():

            userprofile = UserProfile.objects.get(user=user)
            if userprofile.user_type ==1 or userprofile.user_type==3:
                messages.error(request, 'Oops!You Dont Have Permission to Add the Sub Category')
                return HttpResponseRedirect('/appname/sub_category_list/')

            instance = form.instance
            instance.sub_created_by = user

            instance.save()

            form.save()
            messages.success(request, 'Well done!Your Task is Submitted Succesfully.')
            return HttpResponseRedirect('/appname/sub_category_list/')
        else:
            form = SubcategoryForm()
        return render(request, 'sub_category_add.html', {'sub_category_lis': SubCategory.objects.filter(is_active=True), 'form': form})
    except Exception as e:
        print(e)


# @login_required
# def sub_category_list(request):
#     user = request.user
#     return render(request, 'sub_ategory_lis.html', {'sub_category_lis': SubCategory.objects.all()})


@login_required
def update_sub_category(request, pk):
    user = request.user
    instance = get_object_or_404(SubCategory, pk=pk)
    form = SubcategoryForm(request.POST or None, instance=instance)
    if form.is_valid():
        userprofile = UserProfile.objects.get(user=user)
        if not userprofile.user_type == 4:
            messages.error(request, 'You Dont have Permission to Update This')
            return HttpResponseRedirect('/appname/sub_category_list/')
        form.save()
        messages.success(
        request, 'Well done!Your Data is Updated Succesfully.')
        return HttpResponseRedirect('/appname/sub_category_list/')
    return render(request, 'sub_category_update.html', {'form': form, 'instance': instance})


# def add_task_history(request, pk):
#     try:
#         user = request.user

#         if request.method =='POST':

#             form2 = TaskHistoryCommntForm(request.POST)

#             if form2.is_valid():

#                 instance = form2.instance

#                 task_id = get_object_or_404(Task, pk=pk)

#                 instance.task = task_id

#                 form2.save()

#                 instance.save()

#                 messages.success(
#                     request, 'Well done!Your Task History is Added Succesfully.')
#             else:
#                 form = TaskHistoryCommntForm()
#         return render(request, 'task_update.html', {'form2': form2})
#     except Exception as e:
#         print(e)

class TaskDetailView(LoginRequiredMixin, DetailView):
    template_name = 'task_update.html'
    model = Task

    def get_context_data(self, **kwargs):
        context = super(TaskDetailView, self).get_context_data(**kwargs)
        context['form'] = TaskCommentForm()

        context['user'] = self.request.user

        today_date = date.today()

        context['post'] = Task.objects.get(pk=self.kwargs.get('pk'))

        context['late_action_app'] = context['post'].late_action_approval

        context['form2'] = LateApprovalForm(instance=context['post'])

        print("This is context in form", context['post'].due_date)

        computed_expected_date = context['post'].due_date - timedelta(days=2)

        context['computed_expected_date'] = computed_expected_date

        context['today_date'] = today_date

        # if computed_expected_date >= today_date:
        #     context[True] = True
        # else:
        #     context[False] = False
        # print("context is", context)

        # context['computed_sum'] = computed_expected_date

        # if context['computed_expected_date']:
        #     Task.objects.create(late_approval_reason=self.request.POST['late_approval_reason'])
        # else:
        #     print(False)

       
        context['form1'] = UpdateTaskForm(instance=context['post'])
        
        # context['userprofile'] = UserProfile.objects.get(user=self.request.user)
        # context['form3'] = UserProfileUpdateForm(instance=context['post'])
        return context

class TaskCommentView(LoginRequiredMixin, View):

    def post(self, request, *args, **kwargs):
        user = request.user
        form = TaskCommentForm(request.POST)
        post = Task.objects.get(pk=self.kwargs.get('pk'))
        if form.is_valid():
            instance = form.instance 
            instance.comment_task = post
            instance.task_comment_update_by = user
            form.save()
            messages.success(
                request, 'Well done!Your Comment is Added Succesfully.')
        else:
            print form.errors
        return HttpResponseRedirect(
            '/appname/{0}/detail/'.format(self.kwargs.get('pk')))

class TaskupdateView(LoginRequiredMixin, View):

    def post(self, request, *args, **kwargs):
        user = request.user
        post = Task.objects.get(pk=self.kwargs.get('pk'))
        form1 = UpdateTaskForm(request.POST, instance=post)
        if form1.is_valid():
            userprofile = UserProfile.objects.get(user=user)
            if userprofile.user_type ==1:
                messages.error(request, 'Oops!You Dont Have Permission to Update the Task')
                return HttpResponseRedirect('/appname/create/')
            instance = form1.instance
            instance.task_updated_by = user
            instance.save()
            form1.save()
            messages.success(
                request, 'Well done!Your Task is updated succesfully.')
        else:
            print form1.errors
        return HttpResponseRedirect(
            '/appname/{0}/detail/'.format(post.id))


class LateReasonView(LoginRequiredMixin, View):

    def post(self, request, *args, **kwargs):
        user = request.user
        post = Task.objects.get(pk=self.kwargs.get('pk'))


        form2 = LateApprovalForm(request.POST, instance=post)

        if form2.is_valid():
            instance = form2.instance
            instance.late_action_approval = 'Yes'
            instance.save()
            # instance = form2.instance
            # instance.task_updated_by = user
            # instance.save()
            form2.save()
            messages.success(
                request, "Well Done!Data is added Succesfully")
        else:
            print form2.errors
        return HttpResponseRedirect('/appname/task_list_assigny/')



@login_required
def not_startd_task(request):
    try:
        user = request.user
        context = {}
        today_date = date.today()
        not_started_task_lis = Task.objects.filter(expected_closure_date__lte=today_date, assignee_status='NOT STARTED')
        return render(request, 'not_started_task.html', {'not_started_task_lis': not_started_task_lis})
    except Exception as e:
        print(e)

@login_required
def overdue_task_list(request):
    try:
        user = request.user
        today_date = date.today()
        overdue_task = Task.objects.filter(expected_closure_date__lte=today_date)
        return render(request, 'overdue_task_list.html', {'books': overdue_task, 'today_date':date.today()})
    except Exception as e:
        print(e)

# @login_required
# def not_started_task_count(request):
#     try:
#         user = request.user
#         lis = []
#         context = {}
#         task_lists = Task.objects.filter(is_active=True)
#         today_date = date.today()
#         for task_list in task_lists:
#             if task_list.assigny_closure_date>today_date and task_list.assignee_status=='NOT STARTED':
#                 lis.append(task_list)
#                 # context['task_list'] = len(lis)
#         print("count", len(lis))
#         return render(request, 'dashboard.html', {'not_started_count':len(lis)})
#         # return render(request, 'dashboard.html', {'closed_task': Task.objects.filter(task_status='CLOSED').count()})
#     except Exception as e:
#         print(e)

#list of element to requesting for late approve

# This is from superuser side

@login_required
def waiting_approval_list(request):
    try:
        user = request.user
        approval_list = Task.objects.filter(late_action_approval='Yes',late_action_approval_status='PENDING')
        return render(request, 'waiting_approval_lis.html', {'approval_list': approval_list, 'today_date':date.today()})
    except Exception as e:
        print(e)

# This is for superuser
@login_required
def approve_late_task(request, pk):
    try:
        user = request.user
        instance = get_object_or_404(Task, pk=pk)
        instance.late_action_approval_status = 'APPROVED'
        instance.late_action_approval = 'No'
        # instance.comment_task.update(task_comment_stage='LATE ACTION APPROVED')
        instance.reviwer_closure_date = datetime.date.today()
        instance.save()
        messages.success(request, 'Well Done! Task is Approved Succesfully')
        return HttpResponseRedirect('/appname/waiting_approval_list/')
    except Exception as e:
        print(e)

@login_required
def change_password(request):
    username = request.user
    if request.method == "POST":
        if request.POST['password1'] == request.POST['password2']:
            request.user.set_password(request.POST['password1'])
            request.user.save()
            messages.success(request, "Password reset successfully.Login With New Password ")
            return HttpResponseRedirect("/appname/create_task/")
        else:
            messages.success(request, "Error! Try again Password did not match")
            return render(request, 'change_password.html', {'username':username})
    else:
        return render(request, 'change_password.html', {'username':username})


# @login_required
# def late_approval_sanction(request):
#     try:
#         instance = get_object_or_404(Task, pk=pk)
#         instance.late_action_approval_status = 'APPROVED'
#         instance.save()
#     except Exception as e:
#         print(e)


# @login_required
# def closed_task_count(request):
#     try:
#         user = request.user
#         closed_task = Task.objects.filter(task_status='CLOSED').count()
#         return render(request, 'count.html', {'closed_task': closed_task})
#     except Exception as e:
#         print(e)